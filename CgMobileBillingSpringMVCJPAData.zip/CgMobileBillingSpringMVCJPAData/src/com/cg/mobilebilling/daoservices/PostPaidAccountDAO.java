package com.cg.mobilebilling.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;

public interface PostPaidAccountDAO  extends JpaRepository<PostpaidAccount,Long>{
	@Query("select a from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	PostpaidAccount getPostPaidAccountDetails(@Param("customer") Customer customer, @Param("mobileNo") long mobileNo);
	@Query("select a from PostpaidAccount a where a.customer=:customer")
	List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(@Param("customer") Customer customer);
	@Query("select a.plan from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	Plan getCustomerPostPaidAccountPlanDetails(@Param("customer") Customer customer,@Param("mobileNo") long mobileNo);
	@Query("delete from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	boolean closeCustomerPostPaidAccount(@Param("customer") Customer customer,@Param("mobileNo") long mobileNo);
	@Query("select a.bills from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	List<Bill> getCustomerPostPaidAccountAllBillDetails(@Param("customer") Customer customer,@Param("mobileNo") long mobileNo);
}
