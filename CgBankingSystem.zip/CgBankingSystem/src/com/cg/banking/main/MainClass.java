package com.cg.banking.main;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, SQLException, AccountBlockedException {
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices=(BankingServices) context.getBean("bankingServices");
			bankingServices.openAccount("savings", 12000, 1234, "Active");
			/*System.out.println(bankingServices.getAccountDetails(1));*/
			System.out.println(bankingServices.depositAmount(1, 1200));
			System.out.println(bankingServices.getAccountDetails(1));
			System.out.println(bankingServices.getTransactionDetails(bankingServices.getAccountDetails(1)));
	}

}
