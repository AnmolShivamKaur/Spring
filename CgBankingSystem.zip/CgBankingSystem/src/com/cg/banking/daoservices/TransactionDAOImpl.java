package com.cg.banking.daoservices;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
@Component("transactionDAO")
public class TransactionDAOImpl implements TransactionRepository {
	@Autowired
	EntityManagerFactory factory;

	@Override
	public ArrayList<Transaction> getTransactionDetails(Account account) {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createNamedQuery("getAllAccountTransactions");
		query.setParameter("account", account);
		ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
		return list;
	}

}
