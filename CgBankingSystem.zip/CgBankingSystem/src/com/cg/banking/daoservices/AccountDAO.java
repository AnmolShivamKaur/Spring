package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface AccountDAO extends JpaRepository<Account, Integer>{
/*	Account saveAccountDetails(Account account) throws SQLException;
	Account getAccountDetails(long accountNo) throws SQLException;
	int updateTransaction(Transaction transaction);
	ArrayList<Transaction> getAccountAllTransactionDetails(long accountNumber);
	ArrayList<Account> getAllAccountDetails();
	String getAccountStatus(long accountNo);
	public boolean update(Account account) throws SQLException;*/

}
