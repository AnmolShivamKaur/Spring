package com.cg.banking.daoservices;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface TransactionRepository {
	ArrayList<Transaction> getTransactionDetails(Account account);

}
