package com.cg.banking.daoservices;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface TransactionDAO extends JpaRepository<Transaction, Integer>{
	@Query("select a from Transaction a where a.account=:account")
	ArrayList<Transaction> getAccountAllTransactionDetails(@Param("account") Account account);
}
