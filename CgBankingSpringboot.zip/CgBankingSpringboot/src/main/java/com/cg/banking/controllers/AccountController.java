package com.cg.banking.controllers;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.NoTransactionsFoundException;
import com.cg.banking.services.BankingServices;


@Controller
public class AccountController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/openAccount1")
	public ModelAndView registerAssociateAction(@ModelAttribute Account account) throws InvalidAmountException {
		account =bankingServices.openAccount(account);
		return new ModelAndView("accountOpenedSuccessPage", "account", account);
	}
	@RequestMapping("/depositAmount1")
	public ModelAndView DepositAmount(@RequestParam("accountNo") long accountNo,@RequestParam("amount") float amount) throws InvalidAmountException, AccountNotFoundException {
		float accountBalance =bankingServices.depositAmount(accountNo,amount);
		return new ModelAndView("transactionSuccessPage", "accountBalance", accountBalance );
	}
	@RequestMapping("/fundTransfer")
	public ModelAndView TransferAmount(@RequestParam("accountNoFrom") long accountNoFrom,@RequestParam("accountNoTo") long accountNoTo,@RequestParam("amount") float amount,@RequestParam("pinNumber") int pinNumber) throws InvalidAmountException, AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException {
		float accountBalance =bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNumber);
		return new ModelAndView("transactionSuccessPage", "accountBalance", accountBalance );
	}
	@RequestMapping("/withdraw")
	public ModelAndView WithdrawAmount(@RequestParam("accountNo") long accountNo,@RequestParam("amount") float amount,@RequestParam("pinNumber") int pinNumber) throws InvalidAmountException, AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException {
		float accountBalance =bankingServices.withdrawAmount(accountNo, amount, pinNumber);
		return new ModelAndView("transactionSuccessPage", "accountBalance", accountBalance );
	}
	@RequestMapping("/getTransaction")
	public ModelAndView TransactionDetails(@RequestParam("accountNo") long accountNo) throws InvalidAmountException, AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, NoTransactionsFoundException {
		Account account=bankingServices.getAccountDetails(accountNo);
		ArrayList<Transaction>transactions =bankingServices.getAccountAllTransaction(account);
		return new ModelAndView("displayTransactionDetails", "transactions", transactions );
	}
	@RequestMapping("/getAccountDetails")
	public ModelAndView AccountDetails(@RequestParam("accountNo") long accountNo) throws InvalidAmountException, AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException, NoTransactionsFoundException {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("displayAccountDetails", "account", account );
	}

}
