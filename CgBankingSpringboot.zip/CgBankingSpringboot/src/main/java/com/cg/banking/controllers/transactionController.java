package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.cg.banking.services.BankingServices;

@Controller
public class transactionController {
	@Autowired
	private BankingServices bankingServices;


}
