package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenAccountStepDefinition {
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
	    
	}

	@When("^User enter his correct credentials and click on submit button$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button() throws Throwable {
	 
	}

	@Then("^User is redirected to registration success page$")
	public void user_is_redirected_to_registration_success_page() throws Throwable {
	  
	}


}
