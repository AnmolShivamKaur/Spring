package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FundTransferStepDefinition {
	@Given("^User is on fund transfer Page$")
	public void user_is_on_fund_transfer_Page() throws Throwable {
	  
	}

	@When("^User enter all of his details and click on fund transfer button$")
	public void user_enter_all_of_his_details_and_click_on_fund_transfer_button() throws Throwable {
	 
	}

	@Then("^User is redirected to same page and message is displayed$")
	public void user_is_redirected_to_same_page_and_message_is_displayed() throws Throwable {

	}

}
