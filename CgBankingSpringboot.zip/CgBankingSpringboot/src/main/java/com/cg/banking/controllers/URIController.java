package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
@Controller
public class URIController {
	Account account;
	Transaction transaction;
	
	@RequestMapping("/")
	public String getIndexPage()
	{
		return "indexPage";
	}
	
	@RequestMapping("/openAccount")
	public String getOpenAccountPage() {
		return "openAccountPage";
	}
	@RequestMapping("/depositAmount")
	public String depositAmountPage() {
		return "depositAmountPage";
	}
	@RequestMapping("/transferFund")
	public String fundTransferPage() {
		return "fundTransferPage";
	}
	@RequestMapping("/withdrawal")
	public String withdrawPage() {
		return "withdrawPage";
	}
	@RequestMapping("/displayTransactions")
	public String displayTransactionsPage() {
		return "displayTransactionsPage";
	}
	@RequestMapping("/displayAccount")
	public String displayAccountPage() {
		return "displayAccountPage";
	}
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}
	@ModelAttribute
	public Transaction createTransaction() {
		transaction=new Transaction();
		return transaction;
	}

}
