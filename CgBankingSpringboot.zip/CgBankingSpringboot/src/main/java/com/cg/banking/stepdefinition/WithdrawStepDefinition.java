package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WithdrawStepDefinition {
	@Given("^User is on withdraw Page$")
	public void user_is_on_withdraw_Page() throws Throwable {
	    
	}

	@When("^User enter all of his details and click on withdraw button$")
	public void user_enter_all_of_his_details_and_click_on_withdraw_button() throws Throwable {
	   
	}

	@Then("^User is redirected to home page and money gets withdraw from his account$")
	public void user_is_redirected_to_home_page_and_money_gets_withdraw_from_his_account() throws Throwable {
	    
	}

}
