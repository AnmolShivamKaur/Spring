package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BankingHomPageStepDefinition {
	@Given("^User is on home Page$")
	public void user_is_on_home_Page() throws Throwable {
	  
	}

	@When("^User clicks on open account link$")
	public void user_clicks_on_open_account_link() throws Throwable {
	  
	}

	@Then("^User is redirected to registration page$")
	public void user_is_redirected_to_registration_page() throws Throwable {
	    
	}

	@When("^User click on deposit link on home page$")
	public void user_click_on_deposit_link_on_home_page() throws Throwable {
	   
	}

	@Then("^User is redirected to deposit page$")
	public void user_is_redirected_to_deposit_page() throws Throwable {
	
	}

	@When("^User click on withdraw link on home page$")
	public void user_click_on_withdraw_link_on_home_page() throws Throwable {
	    
	}

	@Then("^User is redirected to withdraw page$")
	public void user_is_redirected_to_withdraw_page() throws Throwable {
	    
	}

	@When("^User click on fund transfer link on home page$")
	public void user_click_on_fund_transfer_link_on_home_page() throws Throwable {
	
	}

	@Then("^User is redirected to fund transfer page$")
	public void user_is_redirected_to_fund_transfer_page() throws Throwable {
	    
	}

	@When("^User click on change pin link on home page$")
	public void user_click_on_change_pin_link_on_home_page() throws Throwable {
	    
	}

	@Then("^User is redirected to change pin page$")
	public void user_is_redirected_to_change_pin_page() throws Throwable {

	}

	@When("^User click on get specific account details link on home page$")
	public void user_click_on_get_specific_account_details_link_on_home_page() throws Throwable {
	    
	}

	@Then("^User is redirected to get account details page$")
	public void user_is_redirected_to_get_account_details_page() throws Throwable {
	   
	}

	@When("^User click on Get All Account Details link on home page$")
	public void user_click_on_Get_All_Account_Details_link_on_home_page() throws Throwable {
	 
	}

	@Then("^User is redirected to get all account details page$")
	public void user_is_redirected_to_get_all_account_details_page() throws Throwable {
	 
	}

	@When("^User click on get account status link on home page$")
	public void user_click_on_get_account_status_link_on_home_page() throws Throwable {
	    
	}

	@Then("^User is redirected to account status page$")
	public void user_is_redirected_to_account_status_page() throws Throwable {
	
	}

	@When("^User click on unblock account link on home page$")
	public void user_click_on_unblock_account_link_on_home_page() throws Throwable {
	   
	}

	@Then("^User is redirected to unblock account page$")
	public void user_is_redirected_to_unblock_account_page() throws Throwable {
	 
	}

	@When("^User click on deactivate account  link on home page$")
	public void user_click_on_deactivate_account_link_on_home_page() throws Throwable {
	 
	}

	@Then("^User is redirected to deactivate account page$")
	public void user_is_redirected_to_deactivate_account_page() throws Throwable {
	    
	}

}
