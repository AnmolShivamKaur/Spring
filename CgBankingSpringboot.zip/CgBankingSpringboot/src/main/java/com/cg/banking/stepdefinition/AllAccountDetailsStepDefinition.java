package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllAccountDetailsStepDefinition {
	@Given("^User is on get all account details Page$")
	public void user_is_on_get_all_account_details_Page() throws Throwable {
	    
	}

	@When("^User click on get all account details button$")
	public void user_click_on_get_all_account_details_button() throws Throwable {
	  
	}

	@Then("^User is redirected to display all account details page$")
	public void user_is_redirected_to_display_all_account_details_page() throws Throwable {
	   
	}
}
