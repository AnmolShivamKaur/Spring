package com.cg.banking.services;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;

import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private TransactionDAO transactionDAO;

	@Override
	public float depositAmount(long accountNo,float amount) throws AccountNotFoundException {
			Account account;
		
				account = getAccountDetails(accountNo);
				account.setAccountBalance(account.getAccountBalance()+amount);
				accountDAO.save(account);
				Transaction transaction=new Transaction(amount,"deposit",account);
				transactionDAO.save(transaction);
			return account.getAccountBalance();	
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException {
		Account account;
			account = getAccountDetails(accountNo);
			if(account.getPinNumber()==pinNumber){
				if(account.getAccountBalance()-amount>1000){
				account.setAccountBalance(account.getAccountBalance()-amount);
				accountDAO.save(account);
				Transaction transaction=new Transaction(amount,"withdraw",account);
				transactionDAO.save(transaction);
				}
				else{
					throw new InsufficientBalanceException();
				}
				return account.getAccountBalance();
			}
			else throw new InvalidPinNumberException();
			
	}
	@Override
	public float fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) throws AccountNotFoundException, InsufficientBalanceException, InvalidPinNumberException{
		Account account1;
			account1 = getAccountDetails(accountNoTo);
			Account account2=getAccountDetails(accountNoFrom);
			if(account2.getPinNumber()==pinNumber){
				if(account2.getAccountBalance()-transferAmount>1000){
					account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
					account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
					accountDAO.save(account1);
					Transaction transaction1=new Transaction(transferAmount,"transfer",account1);
					transactionDAO.save(transaction1);
					accountDAO.save(account2);
					Transaction transaction2=new Transaction(transferAmount,"transfer",account2);
					transactionDAO.save(transaction2);
					return account2.getAccountBalance();
				}
				else throw new InsufficientBalanceException();
			}
		
		else throw new InvalidPinNumberException();
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException {
				Account account=accountDAO.findById(accountNo).get();
				if(account==null) throw new AccountNotFoundException();
				else return account;
	}
	@Override
	public ArrayList<Account> getAllAccountDetails(){
		return (ArrayList<Account>) accountDAO.findAll();
	}
	@Override
	public ArrayList<Transaction> getAccountAllTransaction(Account account) {
		return transactionDAO.getAccountAllTransactionDetails(account);
	}
	@Override
	public Account openAccount(Account account) throws InvalidAmountException {
		
		if(account.getAccountBalance()>=1000){
		accountDAO.save(account);
		return account;}
		else throw new InvalidAmountException();
}
}
