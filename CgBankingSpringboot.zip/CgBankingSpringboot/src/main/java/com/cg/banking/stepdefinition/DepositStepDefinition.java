package com.cg.banking.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DepositStepDefinition {
	@Given("^User is on deposit Page$")
	public void user_is_on_deposit_Page() throws Throwable {
	  
	}

	@When("^User enter all of his details and click on deposit button$")
	public void user_enter_all_of_his_details_and_click_on_deposit_button() throws Throwable {
	   
	}

	@Then("^User is redirected to home page and money gets deposited in his account$")
	public void user_is_redirected_to_home_page_and_money_gets_deposited_in_his_account() throws Throwable {
	  
	}


}
