package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubLoginStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Given("^User is on Github Homepage$")
	public void user_is_on_Github_Homepage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/login/");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	 
	}

	@When("^Enter username and password of github$")
	public void enter_username_and_password_of_github() throws Throwable {
		loginPage.setUsername("anmolshivamkaur@gmail.com");
		loginPage.setPassword("abcdef");
		loginPage.clickSignIn();
	}

	@Then("^Logged in to github$")
	public void logged_in_to_github() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();

	}
	
	@When("^Enter Invalid username and password of github$")
	public void enter_Invalid_username_and_password_of_github() throws Throwable {
	
	}

	@Then("^Error message is displayed$")
	public void error_message_is_displayed() throws Throwable {
	
	}

}
