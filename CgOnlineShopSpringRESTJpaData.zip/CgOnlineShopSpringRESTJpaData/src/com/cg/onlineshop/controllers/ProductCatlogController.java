package com.cg.onlineshop.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShopServices;

@RestController
public class ProductCatlogController {
	@Autowired
	OnlineShopServices onlineShopServices;

	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
		ResponseEntity<String> response=new ResponseEntity<String>("Hello to All", HttpStatus.OK);
		return response;
	}
	@RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		onlineShopServices.acceptProductDetails(product);
	return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}
	@RequestMapping(value="/getProductDetails",produces=MediaType.APPLICATION_STREAM_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundException{
		Product product=onlineShopServices.getProductDetails(productId);
	return new ResponseEntity<>(product,HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAllProductDetails",produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetails(){
		List<Product> productsList=onlineShopServices.getAllProductDetails();
	return new ResponseEntity<>(productsList,HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeProductDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundException{
	onlineShopServices.removeProductDetails(productId);
	return new ResponseEntity<>("Product details with product code"+productId+"successfully deleted.",HttpStatus.OK);
	}
}
