package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class GetCustomerDetailsStepDefinition {
	@Given("^User is on getCustomerDetailsPage Page$")
	public void user_is_on_getCustomerDetailsPage_Page() throws Throwable {
	    
	}

	@Then("^User is redirected to getCustomerDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerDetailsPage_page_and_details_gets_displayed() throws Throwable {
	    
	}
}
