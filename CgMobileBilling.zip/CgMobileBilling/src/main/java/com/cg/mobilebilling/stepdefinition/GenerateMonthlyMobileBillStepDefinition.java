package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateMonthlyMobileBillStepDefinition {
	@Given("^User is on generateMonthlyMobileBillPage Page$")
	public void user_is_on_generateMonthlyMobileBillPage_Page() throws Throwable {
	  
	}

	@When("^User enter his correct credentials and click on submit button$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button() throws Throwable {
	   
	}

	@Then("^User is redirected to generateMonthlyMobileBillPage page and message gets displayed$")
	public void user_is_redirected_to_generateMonthlyMobileBillPage_page_and_message_gets_displayed() throws Throwable {
	  
	}
}
