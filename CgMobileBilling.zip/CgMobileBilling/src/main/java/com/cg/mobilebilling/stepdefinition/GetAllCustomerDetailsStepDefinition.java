package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetAllCustomerDetailsStepDefinition {

	@Given("^User is on index Page$")
	public void user_is_on_index_Page() throws Throwable {

	}

	@When("^User clicks on All Customer Details link$")
	public void user_clicks_on_All_Customer_Details_link() throws Throwable {

	}

	@Then("^User is redirected to getAllCustomerDetailsPage page and get details of all customers$")
	public void user_is_redirected_to_getAllCustomerDetailsPage_page_and_get_details_of_all_customers() throws Throwable {

	}

	@Given("^User is on getAllCustomerDetailsPage Page$")
	public void user_is_on_getAllCustomerDetailsPage_Page() throws Throwable {

	}


}
