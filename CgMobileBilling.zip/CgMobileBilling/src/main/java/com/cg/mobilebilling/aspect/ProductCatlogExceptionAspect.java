package com.cg.mobilebilling.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.mobilebilling.customresponse.CustomResponse;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@ControllerAdvice(basePackages= {"com.cg.mobilebilling.controllers"})
public class ProductCatlogExceptionAspect {
	@ExceptionHandler({CustomerDetailsNotFoundException.class,InvalidBillMonthException.class,
		BillDetailsNotFoundException.class,PlanDetailsNotFoundException.class,
		PostpaidAccountNotFoundException.class,BillingServicesDownException.class})
	public ResponseEntity<CustomResponse> handleException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
/*@ExceptionHandler(InvalidBillMonthException.class)
	public ResponseEntity<CustomResponse> handleInvalidBillMonthException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(BillDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handleBillDetailsNotFoundException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PlanDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse> handlePlanDetailsNotFoundException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PostpaidAccountNotFoundException.class)
	public ResponseEntity<CustomResponse> handlePostpaidAccountNotFoundException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(BillingServicesDownException.class)
	public ResponseEntity<CustomResponse> handleBillingServicesDownException(Exception e){
		CustomResponse response=new CustomResponse(HttpStatus.EXPECTATION_FAILED.value(),e.getMessage());
		System.out.println(response);
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}*/

}
