package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class openPostpaidMobileAccountStepDefinition {
	@Given("^User is on openPostpaidMobileAccountPage Page$")
	public void user_is_on_openPostpaidMobileAccountPage_Page() throws Throwable {
	   
	}

	@Then("^User is redirected to openPostpaidMobileAccountPage page and message gets displayed$")
	public void user_is_redirected_to_openPostpaidMobileAccountPage_page_and_message_gets_displayed() throws Throwable {
	
	}

}
