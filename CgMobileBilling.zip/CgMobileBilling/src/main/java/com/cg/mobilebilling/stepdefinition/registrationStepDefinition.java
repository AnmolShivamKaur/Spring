package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class registrationStepDefinition {
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
	  
	}

	@Then("^User is redirected to registration page and message gets displayed$")
	public void user_is_redirected_to_registration_page_and_message_gets_displayed() throws Throwable {
	   
	}
}
