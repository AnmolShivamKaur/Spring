package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAssociateDetailsStepDefinition {
	private WebDriver driver;
	private RegistrationPage registrationPage;
	
	@Given("^Associate is on 'viewAssociateDetailsPage'$")
	public void associate_is_on_viewAssociateDetailsPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("localhost:4446/getAssociate");	
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	}
	@When("^Associate enters a valid 'associateId'$")
	public void associate_enters_a_valid_associateId() throws Throwable {
		registrationPage.setAssociateId("1");
		registrationPage.Submit();
	}


	@Then("^Associate is directed to 'displayAssociateDetailsPage'$")
	public void associate_is_directed_to_displayAssociateDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}


}
