package com.cg.payroll.services;
import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;


public interface PayrollServices {

	Associate acceptAssociateDetails(Associate associate)throws PayrollServicesDownException;

	int calculateNetSalary(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;

	Associate getAssociateDetails(int associateId)throws AssociateDetailNotFoundException,PayrollServicesDownException;

	ArrayList<Associate> getAllAssociateDetails()throws PayrollServicesDownException;

}
