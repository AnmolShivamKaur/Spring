package com.cg.payroll.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	@Given("^Associate is on registration Page$")
	public void associate_is_on_registration_Page() throws Throwable {
	   
	}

	@When("^Associate enter his correct credentials$")
	public void associate_enter_his_correct_credentials() throws Throwable {
	    
	}

	@Then("^Associate is redirected to registration success page$")
	public void associate_is_redirected_to_registration_success_page() throws Throwable {
	   
	}

}
