package com.cg.payroll.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexPageStepDefinition {
	@Given("^Associate is on index Page$")
	public void associate_is_on_index_Page() throws Throwable {
	   
	}

	@When("^Associate click on registration link$")
	public void associate_click_on_registration_link() throws Throwable {
	   
	}

	@Then("^Associate is redirected to registration page$")
	public void associate_is_redirected_to_registration_page() throws Throwable {
	  
	}

}
