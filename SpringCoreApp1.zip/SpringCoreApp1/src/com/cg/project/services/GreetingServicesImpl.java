package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices {
	@Override
	public void greetUser(String str) {
		System.out.println("Hello "+str);
	}
}
